<?php
// Failing to plan is planning to fail.



?>